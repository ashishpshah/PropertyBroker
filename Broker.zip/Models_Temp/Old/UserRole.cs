﻿namespace Leoz_25
{
	public partial class UserRole : EntitiesBase
	{
		public override long Id { get; set; }
		public string Name { get; set; }
	}
}
