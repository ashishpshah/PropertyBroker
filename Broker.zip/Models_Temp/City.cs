﻿using System;
using System.Collections.Generic;

namespace Broker.Models_Temp;

public partial class City
{
    public long Id { get; set; }

    public string Name { get; set; } = null!;

    public string? State { get; set; }

    public virtual ICollection<Area> Areas { get; set; } = new List<Area>();
}
