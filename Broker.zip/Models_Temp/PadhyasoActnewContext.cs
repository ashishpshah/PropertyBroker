﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Broker.Models_Temp;

public partial class PadhyasoActnewContext : DbContext
{
    public PadhyasoActnewContext()
    {
    }

    public PadhyasoActnewContext(DbContextOptions<PadhyasoActnewContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Property> Properties { get; set; }

    public virtual DbSet<PropertyAmenity> PropertyAmenities { get; set; }

    public virtual DbSet<PropertyAmenityMap> PropertyAmenityMaps { get; set; }

    public virtual DbSet<PropertyCategory> PropertyCategories { get; set; }

    public virtual DbSet<PropertyType> PropertyTypes { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=103.120.179.247;Initial Catalog=padhyaso_ACTNEW;User ID=padhyaso_admin;Password=satest@123;Trust Server Certificate=True;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.HasDefaultSchema("padhyaso_admin");

        modelBuilder.Entity<Property>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Properti__70C9A7351A597973");

            entity.ToTable("Properties", "dbo");

            entity.Property(e => e.AreaSqft).HasColumnType("decimal(10, 2)");
            entity.Property(e => e.BuilderName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.CreatedDate).HasDefaultValueSql("(sysdatetime())");
            entity.Property(e => e.Description).IsUnicode(false);
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.IsDeleted).HasDefaultValue(false);
            entity.Property(e => e.Landmark).IsUnicode(false);
            entity.Property(e => e.OwnerMobile)
                .HasMaxLength(20)
                .IsUnicode(false);
            entity.Property(e => e.OwnerName)
                .HasMaxLength(100)
                .IsUnicode(false);
            entity.Property(e => e.Price).HasColumnType("decimal(12, 2)");
            entity.Property(e => e.Remark)
                .HasMaxLength(500)
                .IsUnicode(false);
            entity.Property(e => e.Status)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasDefaultValue("Active");
            entity.Property(e => e.Title)
                .HasMaxLength(200)
                .IsUnicode(false);
        });

        modelBuilder.Entity<PropertyAmenity>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Property__3214EC071193879A");

            entity.ToTable("PropertyAmenities", "dbo");

            entity.Property(e => e.Name)
                .HasMaxLength(100)
                .IsUnicode(false);
        });

        modelBuilder.Entity<PropertyAmenityMap>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Property__3214EC073F93806D");

            entity.ToTable("PropertyAmenityMap", "dbo");

            entity.Property(e => e.CreatedDate).HasColumnType("datetime");
            entity.Property(e => e.LastModifiedDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<PropertyCategory>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Property__3214EC07B26087DB");

            entity.ToTable("PropertyCategories", "dbo");

            entity.Property(e => e.Name).HasMaxLength(50);
        });

        modelBuilder.Entity<PropertyType>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__Property__516F03B5F79FAECA");

            entity.ToTable("PropertyTypes", "dbo");

            entity.Property(e => e.Name).HasMaxLength(50);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
