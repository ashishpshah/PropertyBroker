﻿Scaffolding has generated all the files and added the required dependencies.

However the Application's Startup code may require additional changes for things to work end to end.
Add the following code to the Configure method in your Application's Startup class if not already done:

        app.UseEndpoints(endpoints =>
        {
          endpoints.MapControllerRoute(
            name : "areas",
            pattern : "{area:exists}/{controller=Home}/{action=Index}/{id?}"
          );
        });
        


Scaffold-DbContext "Data Source=103.143.46.143;Initial Catalog=Padhyaso_Leoz;User ID=Padhyaso_Leoz;Password=1E*t0y5j4NyHeqtrr;TrustServerCertificate=True;" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models -Tables Project_Site_Doc -f